package com.cg.labtwo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.labtwo.dto.Trainee;
import com.cg.labtwo.service.ITraineeService;

@Controller
public class TraineeController 
{
	@Autowired
	ITraineeService traineeservice;
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String getAll()
	{
		return "login";
		
	}
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String operations()
	{
		return "traineeOperations";
	}
	@RequestMapping(value="add",method=RequestMethod.GET)  //add is taken from home.jsp
	public String addTrainee(@ModelAttribute("trai") Trainee tra,Map<String,Object>model)  //linking jsp to dto
	{
		List<String> myDom = new ArrayList<>();
		myDom.add("Please Select");
		myDom.add("JEE");
		myDom.add("Oracle");
		myDom.add("VnV");	
		model.put("dom", myDom);        
		return "addTrainee";
	}
	@RequestMapping(value="insertData",method=RequestMethod.POST)
	public ModelAndView insertTrainee(@Valid @ModelAttribute("trai") Trainee tra, BindingResult result,Map<String,Object>model)
	{
		int id=0;
		if(result.hasErrors())
		{
			List<String> myDom = new ArrayList<>();
			myDom.add("Please Select");
			myDom.add("JEE");
			myDom.add("Oracle");
			myDom.add("VnV");	
			model.put("dom", myDom);
			return new ModelAndView("addTrainee");
		}
		else
		{
			id=traineeservice.addTraineeData(tra);
		}
		return new ModelAndView("traineeOperations", "tdata", id);
	}
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deleteTrainee()
	{
		return "deleteTrainee";
	}
	@RequestMapping(value="dodelete",method=RequestMethod.GET)
	public ModelAndView traineeDelete(@RequestParam("tid") int id) 
	{
		
		List<Trainee> myData = traineeservice.searchTrainee(id);
		//traineeservice.deleteTrainee(id);
		return new ModelAndView("deleteTrainee","delTrainee",myData);
	}
	@RequestMapping(value="delete1",method=RequestMethod.GET)
	public String traineeDelete1(@RequestParam("tid") int id)
	{
		traineeservice.deleteTrainee(id);
		return ("traineeOperations");
	}
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String retrieveTrainee()
	{
		return "retrieve";
	}
	@RequestMapping(value="doretrieve",method=RequestMethod.GET)
	public ModelAndView retrieveTrainee(@RequestParam("tid") int trnid)
	{
		List<Trainee> myData = traineeservice.retrieveTrainee(trnid);
		return new ModelAndView("retrieve","retTrainee",myData);
	}
	@RequestMapping(value="searchAll",method=RequestMethod.GET)
	public ModelAndView retrieveAllTrainee()
	{
		List<Trainee> myData = traineeservice.retrieveAllTrainee();
		return new ModelAndView("retrieveAll","allTrainee",myData);
	}
	@RequestMapping(value="modify",method=RequestMethod.GET)
	public String traineeModify()
	{
		return "modify";
	}
	@RequestMapping(value="domodify",method=RequestMethod.GET)
	public ModelAndView updateTrainee(@RequestParam("tid") int trnid,@ModelAttribute("trai") Trainee t)
	{
		List<Trainee> myData = traineeservice.retrieveTrainee(trnid);
		return new ModelAndView("modify","modify",myData);
	}
	@RequestMapping(value="update1",method=RequestMethod.GET)
	public String employeeDelete1(@ModelAttribute("trai") Trainee tra)
	{
		traineeservice.updateTrainee(tra);
		return "success";
	}
	
}

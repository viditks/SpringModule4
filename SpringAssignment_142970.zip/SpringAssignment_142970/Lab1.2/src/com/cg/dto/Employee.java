package com.cg.dto;

public class Employee 
{
	int empId;
	String empName;
	double salary;
	SBUBean businessUnit;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public SBUBean getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(SBUBean businessUnit) {
		this.businessUnit = businessUnit;
	}
	public Employee(int empId, String empName, double salary,
			SBUBean businessUnit) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.businessUnit = businessUnit;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", salary=" + salary + ", businessUnit=" + businessUnit + "]";
	}
	public void getAllDetails()
	{
		System.out.println(businessUnit.toString());
	}
	
}

package com.cg.dto;

import java.util.List;

public class Employee 
{
	int empId;
	List<EmployeeDetails>empdet;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public List<EmployeeDetails> getEmpdet() {
		return empdet;
	}
	public void setEmpdet(List<EmployeeDetails> empdet) {
		this.empdet = empdet;
	}
}
